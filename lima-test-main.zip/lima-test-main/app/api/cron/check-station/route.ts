import { NextResponse } from "next/server";
import { XMLParser } from "fast-xml-parser";
import { supabaseAdmin, type DepartureRow } from "@/lib/supabase";
import { parseDbTime, diffMinutes } from "@/lib/dbTime";

export const dynamic = "force-dynamic";

type XmlStop = {
  "@_id"?: string;
  "@_eva"?: string | number;
  tl?: Record<string, unknown> | Record<string, unknown>[];
  dp?: Record<string, string | number> | null;
};

function asArray<T>(v: T | T[] | undefined | null): T[] {
  if (v === undefined || v === null) return [];
  return Array.isArray(v) ? v : [v];
}

function pick(obj: unknown, key: string): string | undefined {
  if (!obj || typeof obj !== "object") return undefined;
  const v = (obj as Record<string, unknown>)[key];
  if (v === undefined || v === null) return undefined;
  return String(v);
}

export async function GET(req: Request) {
  const expected = process.env.CRON_SECRET;
  const auth = req.headers.get("authorization") ?? "";
  if (!expected || auth !== `Bearer ${expected}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const stationEva = process.env.STATION_EVA;
  const clientId = process.env.DB_CLIENT_ID;
  const apiKey = process.env.DB_API_KEY;
  if (!stationEva || !clientId || !apiKey) {
    return NextResponse.json(
      { error: "STATION_EVA / DB_CLIENT_ID / DB_API_KEY fehlt" },
      { status: 500 }
    );
  }

  const url = `https://apis.deutschebahn.com/db-api-marketplace/apis/timetables/v1/rchg/${stationEva}`;
  const res = await fetch(url, {
    headers: {
      "DB-Client-Id": clientId,
      "DB-Api-Key": apiKey,
      Accept: "application/xml"
    },
    cache: "no-store"
  });

  if (!res.ok) {
    const body = (await res.text().catch(() => "")).slice(0, 1000);
    return NextResponse.json(
      { error: `DB API ${res.status}`, body, url },
      { status: 502 }
    );
  }

  const xml = await res.text();
  const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_" });
  const parsed = parser.parse(xml) as { timetable?: { s?: XmlStop | XmlStop[] } };
  const stops = asArray(parsed?.timetable?.s);

  const rows: DepartureRow[] = [];
  for (const s of stops) {
    const dp = s.dp;
    if (!dp || typeof dp !== "object") continue; // nur Stops mit Abfahrt
    const tripId = pick(s, "@_id");
    if (!tripId) continue;

    const tl = asArray(s.tl)[0];
    const planned = parseDbTime(pick(dp, "@_pt"));
    const changed = parseDbTime(pick(dp, "@_ct"));
    const delay =
      planned && changed ? diffMinutes(planned, changed) : null;
    const cancelled = pick(dp, "@_cs") === "c";
    const platform = pick(dp, "@_cp") ?? pick(dp, "@_pp") ?? null;
    const path = pick(dp, "@_cpth") ?? pick(dp, "@_ppth") ?? "";
    const destination = path.split("|").filter(Boolean).pop() ?? null;

    rows.push({
      trip_id: tripId,
      station_eva: String(s["@_eva"] ?? stationEva),
      category: tl ? String(tl["@_c"] ?? "") || null : null,
      train_number: tl ? String(tl["@_n"] ?? "") || null : null,
      planned_time: planned,
      changed_time: changed,
      delay_minutes: delay,
      cancelled,
      platform,
      destination
    });
  }

  let upserted = 0;
  if (rows.length > 0) {
    const supa = supabaseAdmin();
    const { error, count } = await supa
      .from("departures")
      .upsert(rows, { onConflict: "trip_id", count: "exact" });
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    upserted = count ?? rows.length;
  }

  return NextResponse.json({
    status: "ok",
    stationEva,
    processed: rows.length,
    upserted,
    timestamp: new Date().toISOString()
  });
}
